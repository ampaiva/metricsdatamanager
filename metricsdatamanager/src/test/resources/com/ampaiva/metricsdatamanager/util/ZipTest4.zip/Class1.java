import com.foo.Foo;

public class Class1 {
	public void method(Foo f){
		f.execute0();
		f.execute1();
		f.execute2();
		f.execute3();
		f.execute4();
		f.execute5();
		f.execute0();
	}
}