package com.sun.j2ee.blueprints.supplierpo.ejb;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.ejb.EntityBean;
import javax.ejb.EntityContext;
import javax.ejb.CreateException;
import javax.ejb.RemoveException;
import javax.ejb.CreateException;
import javax.ejb.FinderException;

import java.util.Iterator;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import com.sun.j2ee.blueprints.contactinfo.ejb.ContactInfoLocal;
import com.sun.j2ee.blueprints.contactinfo.ejb.ContactInfoLocalHome;
import com.sun.j2ee.blueprints.address.ejb.AddressLocal;
import com.sun.j2ee.blueprints.address.ejb.AddressLocalHome;
import com.sun.j2ee.blueprints.lineitem.ejb.LineItem;
import com.sun.j2ee.blueprints.lineitem.ejb.LineItemLocal;
import com.sun.j2ee.blueprints.lineitem.ejb.LineItemLocalHome;

import com.sun.j2ee.blueprints.supplierpo.ejb.OrderStatusNames;
import com.sun.j2ee.blueprints.supplierpo.ejb.JNDINames;

import com.sun.j2ee.blueprints.servicelocator.ejb.ServiceLocator;
import com.sun.j2ee.blueprints.servicelocator.ServiceLocatorException;
public abstract class SupplierOrderEJB implements EntityBean {
  public void ejbPostCreate(SupplierOrder supplierOrder)
                                              throws CreateException {
  try {
      ServiceLocator serviceLocator = new ServiceLocator();
      ContactInfoLocalHome cinforef = (ContactInfoLocalHome)
          serviceLocator.getLocalHome(JNDINames.CINFO_EJB);
      ContactInfoLocal cinfoloc = (ContactInfoLocal)
                      cinforef.create(supplierOrder.getShippingInfo());
      setContactInfo(cinfoloc);
      LineItemLocalHome lineItemref = (LineItemLocalHome)
          serviceLocator.getLocalHome(JNDINames.LI_EJB);
      Collection litems = supplierOrder.getLineItems();
      Iterator it = litems.iterator();
      while((it != null) && (it.hasNext())) {
        LineItem li = (LineItem) it.next();
        LineItemLocal lineItemloc = (LineItemLocal) lineItemref.create(li, 0);
        addLineItem(lineItemloc);
      }
    } catch(ServiceLocatorException ne) {
      throw new CreateException("ServiceLocator Ex while persisting PO CMR :" +
                                ne.getMessage());
    }
  }
}

