import com.foo.Foo;

public class Class2 {
	public void method(Foo f){
		f.execute1();
		f.execute2();
		f.execute3();
		f.execute4();
		f.execute5();
	}
}